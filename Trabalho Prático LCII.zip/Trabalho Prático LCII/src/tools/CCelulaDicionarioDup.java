package tools;

import java.io.Serializable;

class CCelulaDicionarioDup<K, V> implements Serializable {
    K key;
    V value;
    CCelulaDicionarioDup<K, V> prox;
    CCelulaDicionarioDup<K, V> ant;

    // Construtora que anula os três atributos da célula
    CCelulaDicionarioDup() {
        key = null;
        value = null;
        prox = null;
        ant = null;
    }

    // Construtora que inicializa key e value com os argumentos passados
    // por parâmetro e anula a referência à próxima célula
    CCelulaDicionarioDup(K chave, V valor) {
        key = chave;
        value = valor;
        prox = null;
        ant = null;
    }
// Construtora que inicializa todos os atribulos da célula com os argumentos
// passados por parâmetro

    CCelulaDicionarioDup(K chave, V valor, CCelulaDicionarioDup proxima, CCelulaDicionarioDup anterior) {
        key = chave;
        value = valor;
        prox = proxima;
        ant = anterior;
    }
}