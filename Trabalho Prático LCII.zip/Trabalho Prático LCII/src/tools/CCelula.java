package tools;

import java.io.Serializable;

/**
 * @author Rodrigo Richard Gomes
 * @version 1.00 2018/3/16
 * @(#)CCelula.java
 */

public class CCelula<T> implements Serializable {
    public T item;
    public CCelula<T> prox;

    public CCelula(T valorItem, CCelula proxCelula) {
        item = valorItem;
        prox = proxCelula;
    }

    public CCelula(T valorItem) {
        item = valorItem;
        prox = null;
    }

    public CCelula() {
        item = null;
        prox = null;
    }
}