import dados.Endereco;
import dados.Morador;
import tools.CDicionarioDup;
import tools.exeptions.DicionarioDupChaveJaExistente;

import java.io.*;
import java.util.Scanner;

public class Aplication implements Serializable {
    private static final int FAIXA1 = 1;
    private static final int FAIXA2 = 3;
    private static Scanner leia = new Scanner(System.in);
    private boolean parametrosDefinidos = false;
    private double salarioMinimo = 0;
    private int maxMoradores = 0;
    private int maxFilaDeEspera = 0;
    private CDicionarioDup<Integer, Morador> M1 = new CDicionarioDup<>("FAIXA 1");
    private CDicionarioDup<Integer, Morador> M2 = new CDicionarioDup<>("FAIXA 2");
    private CDicionarioDup<Integer, Morador> N = new CDicionarioDup<>("Fila de espera");
    private int contadorMoradores = 0;
    private int contadorFila = 0;
    private String lineSeparator = System.lineSeparator();

    public static void main(String[] args) {
        Aplication app = new Aplication();
        try {
            try {
                app = carregaApp("appdata.bin");
            } catch (ClassNotFoundException | IOException e) {
                e.getStackTrace();
            }
            if (app.parametrosDefinidos) app.menuPrincipal();
            else {
                app.menuInicial();
                if (app.parametrosDefinidos) app.menuPrincipal();
            }
        } finally {
            try {
                salvaApp("appdata.bin", app);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static Aplication carregaApp(String nomeDoArquivo) throws IOException, ClassNotFoundException {
        FileInputStream arquivoLeitura = new FileInputStream("./data/" + nomeDoArquivo);
        ObjectInputStream objLeitura = new ObjectInputStream(arquivoLeitura);
        Aplication app = (Aplication) objLeitura.readObject();
        arquivoLeitura.close();
        objLeitura.close();
        return app;
    }

    private static void salvaApp(String nomeDoArquivo, Aplication app) throws IOException {
        FileOutputStream arquivoGrav = new FileOutputStream("./data/" + nomeDoArquivo);
        ObjectOutputStream objGravar = new ObjectOutputStream(arquivoGrav);
        objGravar.writeObject(app);
        objGravar.flush();
        objGravar.close();
        arquivoGrav.flush();
        arquivoGrav.close();
    }

    private void menuInicial() {
        int opc;
        do {
            System.out.print("" +
                    "1 - Parâmetros" + lineSeparator +
                    "2 - Sair" + lineSeparator +
                    "--> ");
            opc = leia.nextInt();
            switch (opc) {
                case 1:
                    parametros();
                    break;
                case 2:
                    break;
                default:
                    break;
            }
        } while (opc != 2 && !parametrosDefinidos);
        limpaTela();
    }

    private void menuPrincipal() {
        int opc;
        do {
            System.out.print("" +
                    "1 – Cadastrar morador" + lineSeparator +
                    "2 – Imprimir lista de moradores cadastrados" + lineSeparator +
                    //"2.1 – Lista gem simples (apenas CPF e nome do morador)"+lineSeparator+
                    //"2.2 – Listagem completa (todos os dados)"+lineSeparator+
                    "3 – Imprimir fila de espera" + lineSeparator +
                    "4 – Pesquisar morador" + lineSeparator +
                    "5 – Desistência /Exclusão" + lineSeparator +
                    "6 – Sorteio" + lineSeparator +
                    "7 - Parametros" + lineSeparator +
                    "8 - Sair" + lineSeparator +
                    "--> ");
            opc = leia.nextInt();
            switch (opc) {
                case 1:
                    try {
                        cadastrarMorador();
                    } catch (DicionarioDupChaveJaExistente e) {
                        System.out.println("CPF já cadastrado");
                        jumpTela();
                    }
                    break;
                case 2:
                    menuImprecao();
                    break;
                case 3:
                    imprimiFilaDeEspera();
                    break;
                case 4:
                    pesquisarMorador();
                    break;
                case 5:
                    try {
                        desistencia();
                    } catch (DicionarioDupChaveJaExistente dicionarioDupChaveJaExistente) {
                        dicionarioDupChaveJaExistente.printStackTrace();
                    }
                    break;
                case 6:
                    try {
                        sortear();
                    } catch (DicionarioDupChaveJaExistente dicionarioDupChaveJaExistente) {
                        dicionarioDupChaveJaExistente.printStackTrace();
                    }
                    break;
                case 7:
                    menuParametros();
                    break;
                case 8:
                    limpaTela();
                    break;
                default:
                    break;
            }
        } while (opc != 8);
    }

    private void menuParametros() {
        int opc;
        do {
            System.out.print("" +
                    "1 – Ver parametros atuais" + lineSeparator +
                    "2 – Apagar dados e mudar parametros" + lineSeparator +
                    "3 – Voltar" + lineSeparator +
                    "--> ");
            opc = leia.nextInt();
            switch (opc) {
                case 1:
                    mostraParametros();
                    break;
                case 2:
                    mudarParametros();
                    break;
                case 3:
                    limpaTela();
                    break;
                default:
                    break;
            }
        } while (opc != 3);

    }

    private void mostraParametros() {
        System.out.println("" +
                "Máximo na lista: " + maxMoradores + lineSeparator +
                "Máximo na fila: " + maxFilaDeEspera + lineSeparator +
                "Salário mínimo: " + salarioMinimo);
        jumpTela();
    }

    private void mudarParametros() {
        boolean parametrosDefinidos = false;
        CDicionarioDup<Integer, Morador> M1 = new CDicionarioDup<>("FAIXA 1");
        CDicionarioDup<Integer, Morador> M2 = new CDicionarioDup<>("FAIXA 2");
        CDicionarioDup<Integer, Morador> N = new CDicionarioDup<>("Fila de espera");
        int contadorMoradores = 0;
        int contadorFila = 0;
        parametros();
    }

    private void parametros() {
        System.out.print("Insira o número máximo de pessoas na lista de moradores: ");
        maxMoradores = leia.nextInt();
        System.out.print("Insira o número máximo de pessoas na fila de espera: ");
        maxFilaDeEspera = leia.nextInt();
        System.out.print("Insira o valordo salário mínimo: ");
        salarioMinimo = leia.nextDouble();
        limpaTela();
        parametrosDefinidos = true;
    }

    private void sortear() throws DicionarioDupChaveJaExistente {
        System.out.print("Quantas casas serão sorteadas para a Faixa 1:");
        int qnt1 = leia.nextInt();
        System.out.print("Quantas casas serão sorteadas para a Faixa 2:");
        int qnt2 = leia.nextInt();

        for (int i = 0; i < qnt1; i++) {
            double sort = Math.random() * M1.getQuantidade();
            Morador auxSort = M1.recebeValor((int) sort);
            imprecaoCompleta(auxSort);
            M1.remove(auxSort.getCpf());
            Morador aux = N.retornaPrimeiro();
            if (aux != null) {
                if (aux.getRendaFamiliar() <= salarioMinimo) {
                    M1.adiciona(aux.getCpf(), aux);
                    contadorMoradores++;
                    N.remove(aux.getCpf());
                    contadorFila--;
                } else {
                    M2.adiciona(aux.getCpf(), aux);
                    contadorMoradores++;
                    N.remove(aux.getCpf());
                    contadorFila--;
                }
            }
        }

        for (int i = 0; i < qnt2; i++) {
            double sort = Math.random() * M2.getQuantidade();
            Morador auxSort = M2.recebeValor((int) sort);
            imprecaoCompleta(auxSort);
            M2.remove(auxSort.getCpf());
        }

    }

    private void desistencia() throws DicionarioDupChaveJaExistente {
        System.out.print("Insira o CPF de quem deseja desistir: ");
        int cpf = leia.nextInt();
        int aonde;
        Morador imprecao;
        if (M1.chaveJaExiste(cpf)) {
            imprecao = M1.recebeValor(Integer.valueOf(cpf));
            imprecaoCompleta(imprecao);
            aonde = 1;
        } else if (M2.chaveJaExiste(cpf)) {
            imprecao = M2.recebeValor(Integer.valueOf(cpf));
            imprecaoCompleta(imprecao);
            aonde = 2;
        } else if (N.chaveJaExiste(cpf)) {
            imprecao = N.recebeValor(Integer.valueOf(cpf));
            imprecaoCompleta(imprecao);
            aonde = 3;
        } else aonde = 0;
        if (aonde != 0) {
            System.out.print("" +
                    "Confirmar desistência:" + lineSeparator +
                    "1 - Sim" + lineSeparator +
                    "2 - Não" + lineSeparator +
                    "--> ");

            int opc = leia.nextInt();
            if (opc == 1) {
                Morador aux = N.retornaPrimeiro();
                switch (aonde) {
                    case 1:
                        M1.remove(cpf);
                        contadorMoradores--;
                        break;
                    case 2:
                        M2.remove(cpf);
                        contadorMoradores--;
                        break;
                    case 3:
                        N.remove(cpf);
                        contadorFila--;
                        aux = null;
                        break;
                }

                if (aux != null) {
                    if (aux.getRendaFamiliar() <= salarioMinimo) {
                        M1.adiciona(aux.getCpf(), aux);
                        contadorMoradores++;
                        N.remove(aux.getCpf());
                        contadorFila--;
                    } else {
                        M2.adiciona(aux.getCpf(), aux);
                        contadorMoradores++;
                        N.remove(aux.getCpf());
                        contadorFila--;
                    }
                }
                System.out.println("Operação concluída, morador desistiu.");
                jumpTela();

            } else {
                System.out.println("Operação cancelada.");
                jumpTela();
            }
        }
    }

    private void imprecaoCompleta(Morador morador) {
        System.out.println("CPF: " + morador.getCpf() + "    Nome:" + morador.getNome() + lineSeparator +
                "Qtde. Dependentes: " + morador.getQntDeDependentes() + " - Renda familiar: " + morador.getRendaFamiliar() + lineSeparator +
                "Telefone: " + morador.getTelefone() + lineSeparator +
                "Endereço: " + morador.getEndereco().getEndereco() + lineSeparator +
                "Cidade: " + morador.getEndereco().getCidade() + " - Estado: " + morador.getEndereco().getUf() + " - CEP: " + morador.getEndereco().getCep() + lineSeparator);
    }

    private void pesquisarMorador() {
        limpaTela();
        System.out.print("Insira o CPF do morador que deseja procurar: ");
        int cpf = leia.nextInt();
        if (M1.chaveJaExiste(cpf) || getM2().chaveJaExiste(cpf)) {
            System.out.println("Morador cadastrado na lista." + lineSeparator);
        } else if (N.chaveJaExiste(cpf)) {
            System.out.println("Morador cadastrado na fila de espera." + lineSeparator);
        } else {
            System.out.println("Morador não cadastrado" + lineSeparator);
        }

    }

    private int getContadorFila() {
        return contadorFila;
    }

    private void menuImprecao() {
        int opc;
        do {
            System.out.print("" +
                    "1 – Listagem simples (apenas CPF e nome do morador)" + lineSeparator +
                    "2 – Listagem completa (todos os dados)" + lineSeparator +
                    "3 - Voltar" + lineSeparator +
                    "--> ");
            opc = leia.nextInt();
            switch (opc) {
                case 1:
                    imprimeListaMoradoresSimples();
                    break;
                case 2:
                    imprimeListaMoradoresCompleta();
                    break;
                case 3:
                    limpaTela();
                    break;
                default:
                    break;
            }
        } while (opc > 3 || opc < 1);
    }

    private void cadastrarMorador() throws DicionarioDupChaveJaExistente {
        System.out.println("-----------------------------------");
        System.out.print("Insira o CPF: ");
        int cpf = leia.nextInt();
        if (M1.chaveJaExiste(cpf)) {
            throw new DicionarioDupChaveJaExistente();
        }
        System.out.print("Insira o nome completo: ");
        leia.nextLine();
        String nome = leia.nextLine();
        System.out.print("Insira a quantidade de dependes: ");
        int qntDeDependentes = leia.nextInt();
        System.out.print("Insira a renda familiar: ");
        double rendaFamiliar = leia.nextDouble();
        System.out.print("Insira o telefone: ");
        int telefone = leia.nextInt();
        leia.nextLine();
        System.out.print("Insira o logradouro: ");
        String logradouro = leia.nextLine();
        System.out.print("Insira o CEP: ");
        int cep = leia.nextInt();
        leia.nextLine();
        System.out.print("Insira a cidade: ");
        String cidade = leia.nextLine();
        System.out.print("Insira o UF: ");
        String uf = leia.nextLine();
        Endereco endereco = new Endereco(logradouro, cep, cidade, uf);
        Morador morador = new Morador(cpf, nome, qntDeDependentes, rendaFamiliar, telefone, endereco);
        System.out.println("-----------------------------------");
        if (morador.getRendaFamiliar() <= FAIXA1 * salarioMinimo) {
            if (contadorMoradores < maxMoradores) {
                M1.adiciona(morador.getCpf(), morador);
                contadorMoradores++;
                System.out.println("Cadastrado com sucesso na faixa 1.");
            } else if (contadorFila < maxFilaDeEspera) {
                N.adiciona(morador.getCpf(), morador);
                contadorFila = N.getQuantidade();
                System.out.println("Lista cheia. Morador foi cadastrado na fila de espera.");
            } else {
                System.out.println("Sema vagas na fila de espera");
            }
        } else if (morador.getRendaFamiliar() <= FAIXA2 * salarioMinimo) {
            if (contadorMoradores < maxMoradores) {
                M2.adiciona(morador.getCpf(), morador);
                contadorMoradores++;
                System.out.println("Cadastrado com sucesso na faixa 2.");
            } else if (contadorFila < maxFilaDeEspera) {
                N.adiciona(morador.getCpf(), morador);
                contadorFila = N.getQuantidade();
                System.out.println("Lista cheia. Morador foi cadastrado na fila de espera.");
            } else {
                System.out.println("Sema vagas na fila de espera");
            }
        } else System.out.println("Renda familiar não participa do benefício.");
        jumpTela();
    }

    private void imprimeListaMoradoresSimples() {
        int pag = 1;
        System.out.println("LISTAGEM DE MORADORES (PÁGINA " + pag + ")");
        System.out.println("================================");
        int qnt = M1.getQuantidade();
        int auxInt = 0;
        System.out.println(lineSeparator + M1.getTitulo() + ":");
        if (qnt > 0) {
            for (int i = 0; i < qnt; i++) {
                if (auxInt == 20) {
                    quebraDePag(pag);
                    pag++;
                    auxInt = 0;
                }
                Morador aux = M1.recebeValor(i);
                System.out.println("CPF: " + aux.getCpf() + " - Nome:" + aux.getNome() + " - Renda familiar: " + aux.getRendaFamiliar());
                auxInt++;
            }
        } else {
            System.out.println("VAZIA");
        }
        qnt = M2.getQuantidade();
        System.out.println(lineSeparator + M2.getTitulo() + ":");
        if (qnt > 0) {
            for (int i = 0; i < qnt; i++) {
                if (auxInt == 20) {
                    quebraDePag(pag);
                    pag++;
                    auxInt = 0;
                }
                Morador aux = M2.recebeValor(i);
                System.out.println("CPF: " + aux.getCpf() + " - Nome:" + aux.getNome() + " - Renda familiar: " + aux.getRendaFamiliar());
                auxInt++;
            }
        } else {
            System.out.println("VAZIA");
        }
        jumpTela();
    }

    private void imprimeListaMoradoresCompleta() {
        int pag = 1;
        System.out.println("LISTAGEM DE MORADORES (PÁGINA " + pag + ")");
        System.out.println("================================");
        int qnt = M1.getQuantidade();
        int auxInt = 0;
        System.out.println(lineSeparator + M1.getTitulo() + ":");
        if (qnt > 0) {
            for (int i = 0; i < qnt; i++) {
                if (auxInt == 3) {
                    quebraDePag(pag);
                    pag++;
                    auxInt = 0;
                }
                Morador aux = M1.recebeValor(i);
                imprecaoCompleta(aux);
                auxInt++;
            }
        } else {
            System.out.println("VAZIA");
        }
        qnt = M2.getQuantidade();
        System.out.println(lineSeparator + M2.getTitulo() + ":");
        if (qnt > 0) {
            for (int i = 0; i < qnt; i++) {
                if (auxInt == 3) {
                    quebraDePag(pag);
                    pag++;
                    auxInt = 0;
                }
                Morador aux = M2.recebeValor(i);
                imprecaoCompleta(aux);
                auxInt++;
            }
        } else {
            System.out.println("VAZIA");
        }
        jumpTela();
    }

    private void quebraDePag(int pag) {
        leia.nextLine();
        System.out.println(lineSeparator + "Digite enter para continuar...");
        leia.nextLine();
        pag++;
        limpaTela();
        System.out.println("LISTAGEM DE MORADORES (PÁGINA " + pag + ")");
        System.out.println("================================");
    }

    private void imprimiFilaDeEspera() {
        int auxInt = 0;
        int pag = 1;
        int qnt = N.getQuantidade();
        System.out.println("LISTAGEM DE MORADORES NA FILA (PÁGINA " + pag + ")");
        System.out.println("========================================");

        if (qnt > 0) {
            for (int i = 0; i < qnt; i++) {
                Morador aux = N.recebeValor(i);
                if (auxInt == 20) {
                    quebraDePag(pag);
                    pag++;
                    auxInt = 0;
                }
                System.out.println("CPF: " + aux.getCpf() + " - Nome:" + aux.getNome() + " - Renda familiar: " + aux.getRendaFamiliar());
                auxInt++;
            }
        } else {
            System.out.println("VAZIA");
        }
        jumpTela();
    }

    private void jumpTela() {
        System.out.println(lineSeparator + "Digite enter para continuar...");
        if (leia.hasNextLine())
            leia.nextLine();
        leia.nextLine();
        limpaTela();

    }

    private void limpaTela() {
        for (int i = 0; i < 30; ++i)
            System.out.println();
    }

    private CDicionarioDup<Integer, Morador> getM1() {
        return M1;
    }

    private void setM1(CDicionarioDup<Integer, Morador> m1) {
        M1 = m1;
    }

    private CDicionarioDup<Integer, Morador> getM2() {
        return M2;
    }

    private void setM2(CDicionarioDup<Integer, Morador> m2) {
        M2 = m2;
    }

    private CDicionarioDup<Integer, Morador> getN() {
        return N;
    }

    private void setN(CDicionarioDup<Integer, Morador> n) {
        N = n;
    }

    private int getContadorMoradores() {
        return contadorMoradores;
    }

    private void setContadorMoradores(int contadorMoradores) {
        this.contadorMoradores = contadorMoradores;
    }
}
