package dados;

import java.io.Serializable;

public class Morador implements Serializable {
    private int cpf;
    private String nome;
    private int qntDeDependentes;
    private double rendaFamiliar;
    private int telefone;

    public Morador(int cpf, String nome, int qntDeDependentes, double rendaFamiliar, int telefone, Endereco endereco) {
        this.cpf = cpf;
        this.nome = nome;
        this.qntDeDependentes = qntDeDependentes;
        this.rendaFamiliar = rendaFamiliar;
        this.telefone = telefone;
        this.endereco = endereco;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getQntDeDependentes() {
        return qntDeDependentes;
    }

    public void setQntDeDependentes(int qntDeDependentes) {
        this.qntDeDependentes = qntDeDependentes;
    }

    public double getRendaFamiliar() {
        return rendaFamiliar;
    }

    public void setRendaFamiliar(double rendaFamiliar) {
        this.rendaFamiliar = rendaFamiliar;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public Endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Endereco endereco) {
        this.endereco = endereco;
    }

    private Endereco endereco;
}
