package tools.exeptions;

import java.io.Serializable;

public class DicionarioDupChaveJaExistente extends Exception implements Serializable {
    public DicionarioDupChaveJaExistente() {
        super("Dicionário já possui essa chave cadastrada");
    }
}
