package tools;

import dados.Morador;
import tools.exeptions.DicionarioDupChaveJaExistente;

import java.io.Serializable;

public class CDicionarioDup<K, V> implements Serializable {
    private String titulo;
    private CCelulaDicionarioDup<K, V> primeira;
    private CCelulaDicionarioDup<K, V> ultima;
    private int quantidade = 0;

    public CDicionarioDup(String titulo) {
        this.titulo = titulo;
        primeira = new CCelulaDicionarioDup<K, V>();
        ultima = primeira;
    }

    public boolean vazio() {
        return ultima == primeira;
    }

    public void adiciona(K chave, V valor) throws DicionarioDupChaveJaExistente {
        if (recebeValor(chave) == null) {
            ultima.prox = new CCelulaDicionarioDup<K, V>(chave, valor, null, ultima);
            ultima = ultima.prox;
            quantidade++;
        } else throw new DicionarioDupChaveJaExistente();
    }

    public boolean chaveJaExiste(K chave) {
        if (retornaCelula(chave) == null) return false;
        else return true;
    }

    public V recebeValor(K chave) {
        CCelulaDicionarioDup<K, V> aux = retornaCelula(chave);
        if (aux == null) return null;
        else return aux.value;
    }

    public V recebeValor(int index) {
        CCelulaDicionarioDup<K, V> aux = retornaCelula(index);
        if (aux == null) return null;
        else return aux.value;
    }

    public void imprime() {
        CCelulaDicionarioDup<K, V> aux = primeira;
        while (aux.prox != null) {
            if (aux.value instanceof Morador)
                System.out.println(((Morador) aux.prox.value).getNome());
            aux = aux.prox;
        }
    }

    private CCelulaDicionarioDup<K, V> retornaCelula(K chave) {
        CCelulaDicionarioDup<K, V> aux = primeira;
        boolean achou = false;
        while (aux != null && !achou) {
            aux = aux.prox;
            if (aux != null)
                if (aux.key.equals(chave)) {
                    achou = true;
                }
        }
        if (achou) return aux;
        else return null;
    }

    private CCelulaDicionarioDup<K, V> retornaCelula(int index) {
        CCelulaDicionarioDup aux = primeira;
        int i = 0;
        while (i <= index && aux != null) {
            aux = aux.prox;
            i++;
        }
        return aux;
    }

    public void remove(K chave) {
        CCelulaDicionarioDup aux = retornaCelula(chave);
        if (aux != null) {
            if (aux.ant != null)
                aux.ant.prox = aux.prox;
            if (aux.prox != null)
                aux.prox.ant = aux.ant;
            quantidade--;
            if (quantidade == 0) {
                primeira = ultima;
            }
        }
    }

    public void recebePrimeiro() {
        CCelulaDicionarioDup aux = primeira.prox;
        assert aux != null;
        aux.ant.prox = aux.prox;
        aux.prox.ant = aux.ant;
        quantidade--;
    }
    public V retornaPrimeiro() {
        if (!vazio()) return primeira.prox.value;
        else return null;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
}